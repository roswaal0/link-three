import * as i0 from "@angular/core";
export declare class LinkThreeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreeModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreeModule>;
}
