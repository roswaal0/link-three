import * as i0 from "@angular/core";
import * as i1 from "./link-three-mobile-panel.component";
import * as i2 from "@link-three-core";
import * as i3 from "@link-three-view";
import * as i4 from "@angular/common";
import * as i5 from "@ngrx/component";
export declare class LinkThreeMobilePanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeMobilePanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreeMobilePanelModule, [typeof i1.LinkThreeMobilePanelComponent], [typeof i2.LinkThreeMobilePanelContainerModule, typeof i3.LinkThreeMobilePanelViewModule, typeof i4.CommonModule, typeof i5.ReactiveComponentModule], [typeof i1.LinkThreeMobilePanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreeMobilePanelModule>;
}
