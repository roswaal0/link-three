import * as i0 from "@angular/core";
export declare class LinkThreeMobilePanelComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeMobilePanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkThreeMobilePanelComponent, "link-three-mobile-panel", never, {}, {}, never, never>;
}
