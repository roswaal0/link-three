import * as i0 from "@angular/core";
export declare class LinkThreeLinksPanelComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeLinksPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkThreeLinksPanelComponent, "link-three-links-panel", never, {}, {}, never, never>;
}
