import * as i0 from "@angular/core";
import * as i1 from "./link-three-links-panel.component";
import * as i2 from "@link-three-core";
import * as i3 from "@link-three-view";
import * as i4 from "@angular/common";
import * as i5 from "@ngrx/component";
export declare class LinkThreeLinksPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeLinksPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreeLinksPanelModule, [typeof i1.LinkThreeLinksPanelComponent], [typeof i2.LinkThreeLinksPanelContainerModule, typeof i3.LinkThreeLinksPanelViewModule, typeof i4.CommonModule, typeof i5.ReactiveComponentModule], [typeof i1.LinkThreeLinksPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreeLinksPanelModule>;
}
