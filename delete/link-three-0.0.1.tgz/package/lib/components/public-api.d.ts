/**
 * @author Oswaldo Pacheco
 */
export { LinkThreeLinksPanelComponent } from './link-three-links-panel/link-three-links-panel.component';
export { LinkThreeLinksPanelModule } from './link-three-links-panel/link-three-links-panel.module';
