(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('link-three-core'), require('link-three-view'), require('@angular/common'), require('@ngrx/component')) :
    typeof define === 'function' && define.amd ? define('link-three', ['exports', '@angular/core', 'link-three-core', 'link-three-view', '@angular/common', '@ngrx/component'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["link-three"] = {}, global.ng.core, global.i1, global.i2, global.ng.common, global.component));
})(this, (function (exports, i0, i1, i2, common, component) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
    var i1__namespace = /*#__PURE__*/_interopNamespace(i1);
    var i2__namespace = /*#__PURE__*/_interopNamespace(i2);

    var LinkThreeModule = /** @class */ (function () {
        function LinkThreeModule() {
        }
        return LinkThreeModule;
    }());
    LinkThreeModule.ɵfac = function LinkThreeModule_Factory(t) { return new (t || LinkThreeModule)(); };
    LinkThreeModule.ɵmod = /*@__PURE__*/ i0__namespace.ɵɵdefineNgModule({ type: LinkThreeModule });
    LinkThreeModule.ɵinj = /*@__PURE__*/ i0__namespace.ɵɵdefineInjector({ imports: [[]] });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeModule, [{
                type: i0.NgModule,
                args: [{
                        declarations: [],
                        imports: [],
                        exports: []
                    }]
            }], null, null);
    })();

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinksPanelComponent = /** @class */ (function () {
        function LinkThreeLinksPanelComponent() {
        }
        return LinkThreeLinksPanelComponent;
    }());
    LinkThreeLinksPanelComponent.ɵfac = function LinkThreeLinksPanelComponent_Factory(t) { return new (t || LinkThreeLinksPanelComponent)(); };
    LinkThreeLinksPanelComponent.ɵcmp = /*@__PURE__*/ i0__namespace.ɵɵdefineComponent({ type: LinkThreeLinksPanelComponent, selectors: [["link-three-links-panel"]], decls: 3, vars: 0, consts: [["smartComponent", ""]], template: function LinkThreeLinksPanelComponent_Template(rf, ctx) {
            if (rf & 1) {
                i0__namespace.ɵɵelementStart(0, "link-three-links-panel-container", null, 0);
                i0__namespace.ɵɵelement(2, "link-three-links-panel-view");
                i0__namespace.ɵɵelementEnd();
            }
        }, directives: [i1__namespace.LinkThreeLinksPanelContainerComponent, i2__namespace.LinkThreeLinksPanelViewComponent], encapsulation: 2, changeDetection: 0 });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeLinksPanelComponent, [{
                type: i0.Component,
                args: [{
                        selector: 'link-three-links-panel',
                        templateUrl: './link-three-links-panel.component.html',
                        encapsulation: i0.ViewEncapsulation.None,
                        changeDetection: i0.ChangeDetectionStrategy.OnPush
                    }]
            }], null, null);
    })();

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinksPanelModule = /** @class */ (function () {
        function LinkThreeLinksPanelModule() {
        }
        return LinkThreeLinksPanelModule;
    }());
    LinkThreeLinksPanelModule.ɵfac = function LinkThreeLinksPanelModule_Factory(t) { return new (t || LinkThreeLinksPanelModule)(); };
    LinkThreeLinksPanelModule.ɵmod = /*@__PURE__*/ i0__namespace.ɵɵdefineNgModule({ type: LinkThreeLinksPanelModule });
    LinkThreeLinksPanelModule.ɵinj = /*@__PURE__*/ i0__namespace.ɵɵdefineInjector({ imports: [[
                i1.LinkThreeLinksPanelContainerModule,
                i2.LinkThreeLinksPanelViewModule,
                common.CommonModule,
                component.ReactiveComponentModule
            ]] });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeLinksPanelModule, [{
                type: i0.NgModule,
                args: [{
                        imports: [
                            i1.LinkThreeLinksPanelContainerModule,
                            i2.LinkThreeLinksPanelViewModule,
                            common.CommonModule,
                            component.ReactiveComponentModule
                        ],
                        declarations: [
                            LinkThreeLinksPanelComponent
                        ],
                        exports: [
                            LinkThreeLinksPanelComponent
                        ]
                    }]
            }], null, null);
    })();
    (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && i0__namespace.ɵɵsetNgModuleScope(LinkThreeLinksPanelModule, { declarations: [LinkThreeLinksPanelComponent], imports: [i1.LinkThreeLinksPanelContainerModule,
                i2.LinkThreeLinksPanelViewModule,
                common.CommonModule,
                component.ReactiveComponentModule], exports: [LinkThreeLinksPanelComponent] });
    })();

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.LinkThreeLinksPanelComponent = LinkThreeLinksPanelComponent;
    exports.LinkThreeLinksPanelModule = LinkThreeLinksPanelModule;
    exports.LinkThreeModule = LinkThreeModule;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=link-three.umd.js.map
