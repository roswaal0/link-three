import * as i0 from '@angular/core';
import { NgModule, Component, ViewEncapsulation, ChangeDetectionStrategy } from '@angular/core';
import * as i1 from 'link-three-core';
import { LinkThreeLinksPanelContainerModule } from 'link-three-core';
import * as i2 from 'link-three-view';
import { LinkThreeLinksPanelViewModule } from 'link-three-view';
import { CommonModule } from '@angular/common';
import { ReactiveComponentModule } from '@ngrx/component';

class LinkThreeModule {
}
LinkThreeModule.ɵfac = function LinkThreeModule_Factory(t) { return new (t || LinkThreeModule)(); };
LinkThreeModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LinkThreeModule });
LinkThreeModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [[]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [],
                exports: []
            }]
    }], null, null); })();

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelComponent {
}
LinkThreeLinksPanelComponent.ɵfac = function LinkThreeLinksPanelComponent_Factory(t) { return new (t || LinkThreeLinksPanelComponent)(); };
LinkThreeLinksPanelComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LinkThreeLinksPanelComponent, selectors: [["link-three-links-panel"]], decls: 3, vars: 0, consts: [["smartComponent", ""]], template: function LinkThreeLinksPanelComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "link-three-links-panel-container", null, 0);
        i0.ɵɵelement(2, "link-three-links-panel-view");
        i0.ɵɵelementEnd();
    } }, directives: [i1.LinkThreeLinksPanelContainerComponent, i2.LinkThreeLinksPanelViewComponent], encapsulation: 2, changeDetection: 0 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeLinksPanelComponent, [{
        type: Component,
        args: [{
                selector: 'link-three-links-panel',
                templateUrl: './link-three-links-panel.component.html',
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], null, null); })();

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelModule {
}
LinkThreeLinksPanelModule.ɵfac = function LinkThreeLinksPanelModule_Factory(t) { return new (t || LinkThreeLinksPanelModule)(); };
LinkThreeLinksPanelModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LinkThreeLinksPanelModule });
LinkThreeLinksPanelModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [[
            LinkThreeLinksPanelContainerModule,
            LinkThreeLinksPanelViewModule,
            CommonModule,
            ReactiveComponentModule
        ]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeLinksPanelModule, [{
        type: NgModule,
        args: [{
                imports: [
                    LinkThreeLinksPanelContainerModule,
                    LinkThreeLinksPanelViewModule,
                    CommonModule,
                    ReactiveComponentModule
                ],
                declarations: [
                    LinkThreeLinksPanelComponent
                ],
                exports: [
                    LinkThreeLinksPanelComponent
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(LinkThreeLinksPanelModule, { declarations: [LinkThreeLinksPanelComponent], imports: [LinkThreeLinksPanelContainerModule,
        LinkThreeLinksPanelViewModule,
        CommonModule,
        ReactiveComponentModule], exports: [LinkThreeLinksPanelComponent] }); })();

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkThreeLinksPanelComponent, LinkThreeLinksPanelModule, LinkThreeModule };
//# sourceMappingURL=link-three.js.map
