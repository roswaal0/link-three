import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { NgModule, Component, ViewEncapsulation, ChangeDetectionStrategy, Injectable } from '@angular/core';
import { LinkResponse } from '@link-three-api';
import { of } from 'rxjs';
import * as i1 from '@ngrx/store';

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeCoreModule {
}
LinkThreeCoreModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
LinkThreeCoreModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeCoreModule, imports: [CommonModule] });
LinkThreeCoreModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeCoreModule, imports: [[
            CommonModule
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        CommonModule
                    ],
                    exports: []
                }]
        }] });

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelContainerComponent {
    constructor() {
    }
    ngOnInit() {
        this._initialize();
    }
    _initialize() {
        this.links$ = of([
            Object.assign(Object.assign({}, new LinkResponse()), { link: 'google.com', linkId: '123', platform: 'google', userId: 'ozzy' })
        ]);
    }
}
LinkThreeLinksPanelContainerComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksPanelContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
LinkThreeLinksPanelContainerComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: LinkThreeLinksPanelContainerComponent, selector: "link-three-links-panel-container", ngImport: i0, template: "<ng-content></ng-content>\r\n", changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksPanelContainerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'link-three-links-panel-container',
                    templateUrl: './link-three-links-panel-container.component.html',
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush
                }]
        }], ctorParameters: function () { return []; } });

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelContainerModule {
}
LinkThreeLinksPanelContainerModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksPanelContainerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
LinkThreeLinksPanelContainerModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksPanelContainerModule, declarations: [LinkThreeLinksPanelContainerComponent], imports: [CommonModule], exports: [LinkThreeLinksPanelContainerComponent] });
LinkThreeLinksPanelContainerModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksPanelContainerModule, imports: [[
            CommonModule
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksPanelContainerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule
                    ],
                    declarations: [
                        LinkThreeLinksPanelContainerComponent
                    ],
                    exports: [
                        LinkThreeLinksPanelContainerComponent
                    ]
                }]
        }] });

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeMobilePanelContainerComponent {
    constructor() {
    }
    ngOnInit() {
        this._initialize();
    }
    _initialize() { }
}
LinkThreeMobilePanelContainerComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeMobilePanelContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
LinkThreeMobilePanelContainerComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: LinkThreeMobilePanelContainerComponent, selector: "link-three-mobile-panel-container", ngImport: i0, template: "<ng-content></ng-content>\r\n", changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeMobilePanelContainerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'link-three-mobile-panel-container',
                    templateUrl: './link-three-mobile-panel-container.component.html',
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush
                }]
        }], ctorParameters: function () { return []; } });

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeMobilePanelContainerModule {
}
LinkThreeMobilePanelContainerModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeMobilePanelContainerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
LinkThreeMobilePanelContainerModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeMobilePanelContainerModule, declarations: [LinkThreeMobilePanelContainerComponent], imports: [CommonModule], exports: [LinkThreeMobilePanelContainerComponent] });
LinkThreeMobilePanelContainerModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeMobilePanelContainerModule, imports: [[
            CommonModule
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeMobilePanelContainerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule
                    ],
                    declarations: [
                        LinkThreeMobilePanelContainerComponent
                    ],
                    exports: [
                        LinkThreeMobilePanelContainerComponent
                    ]
                }]
        }] });

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksContainerFacade {
    constructor(_store) {
        this._store = _store;
    }
}
LinkThreeLinksContainerFacade.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksContainerFacade, deps: [{ token: i1.Store }], target: i0.ɵɵFactoryTarget.Injectable });
LinkThreeLinksContainerFacade.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksContainerFacade });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeLinksContainerFacade, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.Store }]; } });

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkThreeCoreModule, LinkThreeLinksContainerFacade, LinkThreeLinksPanelContainerComponent, LinkThreeLinksPanelContainerModule, LinkThreeMobilePanelContainerComponent, LinkThreeMobilePanelContainerModule };
//# sourceMappingURL=link-three-core.js.map
