import { Store } from '@ngrx/store';
import * as i0 from "@angular/core";
export declare class LinkThreeLinksContainerFacade {
    private readonly _store;
    constructor(_store: Store);
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeLinksContainerFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LinkThreeLinksContainerFacade>;
}
