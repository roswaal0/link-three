import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class LinkThreeCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreeCoreModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreeCoreModule>;
}
