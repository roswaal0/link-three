/**
 * @author Oswaldo Pacheco
 */
import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class LinkThreeMobilePanelContainerComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    private _initialize;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeMobilePanelContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkThreeMobilePanelContainerComponent, "link-three-mobile-panel-container", never, {}, {}, never, ["*"]>;
}
