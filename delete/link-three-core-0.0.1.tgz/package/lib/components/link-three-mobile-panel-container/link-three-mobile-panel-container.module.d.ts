import * as i0 from "@angular/core";
import * as i1 from "./link-three-mobile-panel-container.component";
import * as i2 from "@angular/common";
export declare class LinkThreeMobilePanelContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeMobilePanelContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreeMobilePanelContainerModule, [typeof i1.LinkThreeMobilePanelContainerComponent], [typeof i2.CommonModule], [typeof i1.LinkThreeMobilePanelContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreeMobilePanelContainerModule>;
}
