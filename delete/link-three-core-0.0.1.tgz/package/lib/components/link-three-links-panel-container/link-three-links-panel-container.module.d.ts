import * as i0 from "@angular/core";
import * as i1 from "./link-three-links-panel-container.component";
import * as i2 from "@angular/common";
export declare class LinkThreeLinksPanelContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeLinksPanelContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreeLinksPanelContainerModule, [typeof i1.LinkThreeLinksPanelContainerComponent], [typeof i2.CommonModule], [typeof i1.LinkThreeLinksPanelContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreeLinksPanelContainerModule>;
}
