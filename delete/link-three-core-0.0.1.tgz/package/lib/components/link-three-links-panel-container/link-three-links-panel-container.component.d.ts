import * as i0 from "@angular/core";
export declare class LinkThreeLinksPanelContainerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeLinksPanelContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkThreeLinksPanelContainerComponent, "link-three-links-panel-container", never, {}, {}, never, ["*"]>;
}
