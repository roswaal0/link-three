(function (global, factory) {
        typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/common'), require('@angular/core'), require('@link-three/link-three-api'), require('rxjs'), require('@ngrx/store')) :
        typeof define === 'function' && define.amd ? define('@link-three/link-three-core', ['exports', '@angular/common', '@angular/core', '@link-three/link-three-api', 'rxjs', '@ngrx/store'], factory) :
        (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global["link-three"] = global["link-three"] || {}, global["link-three"]["link-three-core"] = {}), global.ng.common, global.ng.core, global.linkThreeApi, global.rxjs, global.i1));
})(this, (function (exports, common, i0, linkThreeApi, rxjs, i1) { 'use strict';

        function _interopNamespace(e) {
                if (e && e.__esModule) return e;
                var n = Object.create(null);
                if (e) {
                        Object.keys(e).forEach(function (k) {
                                if (k !== 'default') {
                                        var d = Object.getOwnPropertyDescriptor(e, k);
                                        Object.defineProperty(n, k, d.get ? d : {
                                                enumerable: true,
                                                get: function () { return e[k]; }
                                        });
                                }
                        });
                }
                n["default"] = e;
                return Object.freeze(n);
        }

        var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
        var i1__namespace = /*#__PURE__*/_interopNamespace(i1);

        /**
         * @author Oswaldo Pacheco
         */
        var LinkThreeCoreModule = /** @class */ (function () {
            function LinkThreeCoreModule() {
            }
            return LinkThreeCoreModule;
        }());
        LinkThreeCoreModule.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeCoreModule, deps: [], target: i0__namespace.ɵɵFactoryTarget.NgModule });
        LinkThreeCoreModule.ɵmod = i0__namespace.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeCoreModule, imports: [common.CommonModule] });
        LinkThreeCoreModule.ɵinj = i0__namespace.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeCoreModule, imports: [[
                    common.CommonModule
                ]] });
        i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeCoreModule, decorators: [{
                    type: i0.NgModule,
                    args: [{
                            declarations: [],
                            imports: [
                                common.CommonModule
                            ],
                            exports: []
                        }]
                }] });

        /**
         * @author Oswaldo Pacheco
         */
        var LinkThreeLinksPanelContainerComponent = /** @class */ (function () {
            function LinkThreeLinksPanelContainerComponent() {
            }
            LinkThreeLinksPanelContainerComponent.prototype.ngOnInit = function () {
                this._initialize();
            };
            LinkThreeLinksPanelContainerComponent.prototype._initialize = function () {
                this.links$ = rxjs.of([
                    Object.assign(Object.assign({}, new linkThreeApi.LinkResponse()), { link: 'google.com', linkId: '123', platform: 'google', userId: 'ozzy' })
                ]);
            };
            return LinkThreeLinksPanelContainerComponent;
        }());
        LinkThreeLinksPanelContainerComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksPanelContainerComponent, deps: [], target: i0__namespace.ɵɵFactoryTarget.Component });
        LinkThreeLinksPanelContainerComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: LinkThreeLinksPanelContainerComponent, selector: "link-three-links-panel-container", ngImport: i0__namespace, template: "<ng-content></ng-content>\r\n", changeDetection: i0__namespace.ChangeDetectionStrategy.OnPush, encapsulation: i0__namespace.ViewEncapsulation.None });
        i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksPanelContainerComponent, decorators: [{
                    type: i0.Component,
                    args: [{
                            selector: 'link-three-links-panel-container',
                            templateUrl: './link-three-links-panel-container.component.html',
                            encapsulation: i0.ViewEncapsulation.None,
                            changeDetection: i0.ChangeDetectionStrategy.OnPush
                        }]
                }], ctorParameters: function () { return []; } });

        /**
         * @author Oswaldo Pacheco
         */
        var LinkThreeLinksPanelContainerModule = /** @class */ (function () {
            function LinkThreeLinksPanelContainerModule() {
            }
            return LinkThreeLinksPanelContainerModule;
        }());
        LinkThreeLinksPanelContainerModule.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksPanelContainerModule, deps: [], target: i0__namespace.ɵɵFactoryTarget.NgModule });
        LinkThreeLinksPanelContainerModule.ɵmod = i0__namespace.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksPanelContainerModule, declarations: [LinkThreeLinksPanelContainerComponent], imports: [common.CommonModule], exports: [LinkThreeLinksPanelContainerComponent] });
        LinkThreeLinksPanelContainerModule.ɵinj = i0__namespace.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksPanelContainerModule, imports: [[
                    common.CommonModule
                ]] });
        i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksPanelContainerModule, decorators: [{
                    type: i0.NgModule,
                    args: [{
                            imports: [
                                common.CommonModule
                            ],
                            declarations: [
                                LinkThreeLinksPanelContainerComponent
                            ],
                            exports: [
                                LinkThreeLinksPanelContainerComponent
                            ]
                        }]
                }] });

        /**
         * @author Oswaldo Pacheco
         */
        var LinkThreeMobilePanelContainerComponent = /** @class */ (function () {
            function LinkThreeMobilePanelContainerComponent() {
            }
            LinkThreeMobilePanelContainerComponent.prototype.ngOnInit = function () {
                this._initialize();
            };
            LinkThreeMobilePanelContainerComponent.prototype._initialize = function () {
            };
            return LinkThreeMobilePanelContainerComponent;
        }());
        LinkThreeMobilePanelContainerComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeMobilePanelContainerComponent, deps: [], target: i0__namespace.ɵɵFactoryTarget.Component });
        LinkThreeMobilePanelContainerComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: LinkThreeMobilePanelContainerComponent, selector: "link-three-mobile-panel-container", ngImport: i0__namespace, template: "<ng-content></ng-content>\r\n", changeDetection: i0__namespace.ChangeDetectionStrategy.OnPush, encapsulation: i0__namespace.ViewEncapsulation.None });
        i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeMobilePanelContainerComponent, decorators: [{
                    type: i0.Component,
                    args: [{
                            selector: 'link-three-mobile-panel-container',
                            templateUrl: './link-three-mobile-panel-container.component.html',
                            encapsulation: i0.ViewEncapsulation.None,
                            changeDetection: i0.ChangeDetectionStrategy.OnPush
                        }]
                }], ctorParameters: function () { return []; } });

        /**
         * @author Oswaldo Pacheco
         */
        var LinkThreeMobilePanelContainerModule = /** @class */ (function () {
            function LinkThreeMobilePanelContainerModule() {
            }
            return LinkThreeMobilePanelContainerModule;
        }());
        LinkThreeMobilePanelContainerModule.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeMobilePanelContainerModule, deps: [], target: i0__namespace.ɵɵFactoryTarget.NgModule });
        LinkThreeMobilePanelContainerModule.ɵmod = i0__namespace.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeMobilePanelContainerModule, declarations: [LinkThreeMobilePanelContainerComponent], imports: [common.CommonModule], exports: [LinkThreeMobilePanelContainerComponent] });
        LinkThreeMobilePanelContainerModule.ɵinj = i0__namespace.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeMobilePanelContainerModule, imports: [[
                    common.CommonModule
                ]] });
        i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeMobilePanelContainerModule, decorators: [{
                    type: i0.NgModule,
                    args: [{
                            imports: [
                                common.CommonModule
                            ],
                            declarations: [
                                LinkThreeMobilePanelContainerComponent
                            ],
                            exports: [
                                LinkThreeMobilePanelContainerComponent
                            ]
                        }]
                }] });

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */
        var LinkThreeLinksContainerFacade = /** @class */ (function () {
            function LinkThreeLinksContainerFacade(_store) {
                this._store = _store;
            }
            return LinkThreeLinksContainerFacade;
        }());
        LinkThreeLinksContainerFacade.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksContainerFacade, deps: [{ token: i1__namespace.Store }], target: i0__namespace.ɵɵFactoryTarget.Injectable });
        LinkThreeLinksContainerFacade.ɵprov = i0__namespace.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksContainerFacade });
        i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeLinksContainerFacade, decorators: [{
                    type: i0.Injectable
                }], ctorParameters: function () { return [{ type: i1__namespace.Store }]; } });

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * Generated bundle index. Do not edit.
         */

        exports.LinkThreeCoreModule = LinkThreeCoreModule;
        exports.LinkThreeLinksContainerFacade = LinkThreeLinksContainerFacade;
        exports.LinkThreeLinksPanelContainerComponent = LinkThreeLinksPanelContainerComponent;
        exports.LinkThreeLinksPanelContainerModule = LinkThreeLinksPanelContainerModule;
        exports.LinkThreeMobilePanelContainerComponent = LinkThreeMobilePanelContainerComponent;
        exports.LinkThreeMobilePanelContainerModule = LinkThreeMobilePanelContainerModule;

        Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=link-three-link-three-core.umd.js.map
