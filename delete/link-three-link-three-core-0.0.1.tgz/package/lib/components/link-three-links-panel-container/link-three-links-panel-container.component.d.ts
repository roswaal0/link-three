/**
 * @author Oswaldo Pacheco
 */
import { OnInit } from '@angular/core';
import { LinkResponse } from '@link-three/link-three-api';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class LinkThreeLinksPanelContainerComponent implements OnInit {
    links$: Observable<LinkResponse[]>;
    constructor();
    ngOnInit(): void;
    private _initialize;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeLinksPanelContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkThreeLinksPanelContainerComponent, "link-three-links-panel-container", never, {}, {}, never, ["*"]>;
}
