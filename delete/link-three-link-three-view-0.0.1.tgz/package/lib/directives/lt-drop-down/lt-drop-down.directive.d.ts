/**
 * @author Oswaldo Pacheco
 */
import { ElementRef, EventEmitter, OnDestroy, OnInit, Renderer2 } from '@angular/core';
export declare class LtDropDownDirective implements OnInit, OnDestroy {
    private _elementRef;
    private _renderer;
    dropDownOpenChange: EventEmitter<boolean>;
    autoClose: string;
    private _dropDownToggleElement;
    private _dropDownMenuElement;
    private _contentElement;
    private _clickEventSubscription;
    private _isOpen;
    private readonly _CONTENT_ELEMENT_CLASS;
    private readonly _OPEN_CLASS;
    private readonly _CLICK;
    constructor(_elementRef: ElementRef, _renderer: Renderer2);
    ngOnInit(): void;
    ngOnDestroy(): void;
    open(): void;
    close(): void;
    toggle(): void;
    set dropDownToggleElement(dropDownToggleElement: ElementRef);
    set dropDownMenuElement(dropDownMenuElement: ElementRef);
    private _initialize;
    private _finalize;
    private _build;
    private _listenAutoClose;
    private _autoCloseEvent;
}
