/**
 * @author Oswaldo Pacheco
 */
import { ElementRef, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { LtDropDownDirective } from './lt-drop-down.directive';
export declare class LtDropDownToggleDirective implements OnInit, OnDestroy {
    private _ssDropDownDirective;
    private _elementRef;
    private _renderer;
    ssDisabled: boolean;
    private _contentElement;
    private _clickEventSubscription;
    private readonly _DISABLED_CLASS;
    private readonly _CONTENT_ELEMENT_CLASS;
    private readonly _CLICK;
    constructor(_ssDropDownDirective: LtDropDownDirective, _elementRef: ElementRef, _renderer: Renderer2);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private _initialize;
    private _finalize;
    private _build;
    private _listenDropDown;
    private _getClickElement;
    private _toggle;
}
