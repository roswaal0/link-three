/**
 * @author Oswaldo Pacheco
 */
export declare enum LtDropDownCloseEnum {
    ALWAYS = "always",
    DISABLED = "disabled",
    OUTSIDE = "outside"
}
