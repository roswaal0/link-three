/**
 * @author Oswaldo Pacheco
 */
import { ElementRef, OnInit, Renderer2 } from '@angular/core';
import { LtDropDownDirective } from './lt-drop-down.directive';
export declare class LtDropDownMenuDirective implements OnInit {
    private _ssDropDownDirective;
    private _elementRef;
    private _renderer;
    private _contentElement;
    private readonly _CONTENT_ELEMENT_CLASS;
    constructor(_ssDropDownDirective: LtDropDownDirective, _elementRef: ElementRef, _renderer: Renderer2);
    ngOnInit(): void;
    private _initialize;
}
