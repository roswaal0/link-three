export declare class LinkThreeViewModule {
}
