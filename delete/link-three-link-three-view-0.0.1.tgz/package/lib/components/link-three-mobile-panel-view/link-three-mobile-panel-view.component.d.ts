export declare class LinkThreeMobilePanelViewComponent {
    constructor();
}
