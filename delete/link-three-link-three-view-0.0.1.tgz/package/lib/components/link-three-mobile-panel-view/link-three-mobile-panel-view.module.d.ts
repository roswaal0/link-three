export declare class LinkThreeMobilePanelViewModule {
}
