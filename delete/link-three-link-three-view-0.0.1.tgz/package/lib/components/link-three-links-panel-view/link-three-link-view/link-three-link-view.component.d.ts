import { LinkResponse } from '@link-three/link-three-api';
export declare class LinkThreeLinkViewComponent {
    link: LinkResponse;
    readonly LINK_LABEL: string;
    readonly PLATFORM_LABEL: string;
    readonly REMOVE_LABEL: string;
    constructor();
}
