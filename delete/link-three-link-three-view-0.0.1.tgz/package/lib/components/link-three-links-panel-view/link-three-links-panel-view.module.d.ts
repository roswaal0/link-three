export declare class LinkThreeLinksPanelViewModule {
}
