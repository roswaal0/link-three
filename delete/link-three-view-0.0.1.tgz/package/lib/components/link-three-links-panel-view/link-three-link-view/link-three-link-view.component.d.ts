export declare class LinkThreeLinkViewComponent {
}
