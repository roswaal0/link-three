/**
 * @author Oswaldo Pacheco
 */
import { AfterViewInit } from '@angular/core';
import { LinkResponse } from '@link-three-api';
export declare class LinkThreeLinksPanelViewComponent implements AfterViewInit {
    links: LinkResponse[] | null;
    readonly ADD_LABEL: string;
    readonly DESCRIPTION_EDITOR_LABEL: string;
    readonly DESCRIPTION_GUIDE_LABEL: string;
    readonly SAVE_LABEL: string;
    readonly TITLE_EDITOR_LABEL: string;
    readonly TITLE_GUIDE_LABEL: string;
    constructor();
    ngAfterViewInit(): void;
}
