export declare class LinkThreeLinksPanelViewComponent {
}
