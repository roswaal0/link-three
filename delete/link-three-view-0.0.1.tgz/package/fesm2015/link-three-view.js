import { CommonModule } from '@angular/common';
import { NgModule, Component, ViewEncapsulation, ChangeDetectionStrategy } from '@angular/core';

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeViewModule {
}
LinkThreeViewModule.decorators = [
    { type: NgModule, args: [{
                declarations: [],
                imports: [
                    CommonModule
                ],
                exports: []
            },] }
];

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinkViewComponent {
}
LinkThreeLinkViewComponent.decorators = [
    { type: Component, args: [{
                selector: 'link-three-link-view.component',
                template: "",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            },] }
];

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelViewComponent {
}
LinkThreeLinksPanelViewComponent.decorators = [
    { type: Component, args: [{
                selector: 'link-three-links-panel-view',
                template: "<div>HOLAAAAAAAAAAAA</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            },] }
];

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelViewModule {
}
LinkThreeLinksPanelViewModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                declarations: [
                    LinkThreeLinkViewComponent,
                    LinkThreeLinksPanelViewComponent
                ],
                exports: [
                    LinkThreeLinkViewComponent,
                    LinkThreeLinksPanelViewComponent
                ],
                providers: []
            },] }
];

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkThreeLinkViewComponent, LinkThreeLinksPanelViewComponent, LinkThreeLinksPanelViewModule, LinkThreeViewModule };
//# sourceMappingURL=link-three-view.js.map
