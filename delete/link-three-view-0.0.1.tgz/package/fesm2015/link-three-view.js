import { CommonModule } from '@angular/common';
import { NgModule, EventEmitter, Directive, ElementRef, Renderer2, Output, Input, Host, Component, ViewEncapsulation, ChangeDetectionStrategy } from '@angular/core';
import { Subscription, fromEvent } from 'rxjs';

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeViewModule {
}
LinkThreeViewModule.decorators = [
    { type: NgModule, args: [{
                declarations: [],
                imports: [
                    CommonModule
                ],
                exports: []
            },] }
];

/**
 * @author Oswaldo Pacheco
 */
var LtDropDownCloseEnum;
(function (LtDropDownCloseEnum) {
    LtDropDownCloseEnum["ALWAYS"] = "always";
    LtDropDownCloseEnum["DISABLED"] = "disabled";
    LtDropDownCloseEnum["OUTSIDE"] = "outside";
})(LtDropDownCloseEnum || (LtDropDownCloseEnum = {}));

/**
 * @author Oswaldo Pacheco
 */
class LtDropDownDirective {
    constructor(_elementRef, _renderer) {
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this._CONTENT_ELEMENT_CLASS = 'lt-drop-down';
        this._OPEN_CLASS = 'lt-drop-down-open';
        this._CLICK = 'click';
        this.dropDownOpenChange = new EventEmitter();
        this._clickEventSubscription = new Subscription();
        this.autoClose = LtDropDownCloseEnum.ALWAYS;
        this._isOpen = false;
    }
    ngOnInit() {
        this._initialize();
    }
    ngOnDestroy() {
        this._finalize();
    }
    open() {
        if (!this._isOpen) {
            this._isOpen = true;
            if (this.autoClose !== LtDropDownCloseEnum.DISABLED) {
                this._listenAutoClose();
            }
            this._renderer.addClass(this._contentElement, this._OPEN_CLASS);
            this.dropDownOpenChange.emit(true);
        }
    }
    close() {
        if (this._isOpen) {
            this._isOpen = false;
            this._renderer.removeClass(this._contentElement, this._OPEN_CLASS);
            this._clickEventSubscription.unsubscribe();
            this.dropDownOpenChange.emit(false);
        }
    }
    toggle() {
        if (this._isOpen) {
            this.close();
        }
        else {
            this.open();
        }
    }
    set dropDownToggleElement(dropDownToggleElement) {
        this._dropDownToggleElement = dropDownToggleElement;
    }
    set dropDownMenuElement(dropDownMenuElement) {
        this._dropDownMenuElement = dropDownMenuElement;
    }
    _initialize() {
        this._build();
    }
    _finalize() {
        this._clickEventSubscription.unsubscribe();
        if (this._dropDownMenuElement) {
            this._dropDownMenuElement.nativeElement.remove();
        }
    }
    _build() {
        this._contentElement = this._elementRef.nativeElement;
        this._renderer.addClass(this._contentElement, this._CONTENT_ELEMENT_CLASS);
    }
    _listenAutoClose() {
        this._clickEventSubscription = fromEvent(document, this._CLICK)
            .subscribe((event) => {
            this._autoCloseEvent(event);
        });
    }
    _autoCloseEvent(event) {
        if (event) {
            const targetElement = event.target;
            if (this._dropDownToggleElement &&
                this._dropDownToggleElement.nativeElement.contains(targetElement)) {
                return;
            }
            if (this.autoClose === LtDropDownCloseEnum.OUTSIDE &&
                this._dropDownMenuElement &&
                this._dropDownMenuElement.nativeElement.contains(targetElement)) {
                return;
            }
        }
        this.close();
    }
}
LtDropDownDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ltDropDown]'
            },] }
];
LtDropDownDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 }
];
LtDropDownDirective.propDecorators = {
    dropDownOpenChange: [{ type: Output }],
    autoClose: [{ type: Input }]
};

/**
 * @author Oswaldo Pacheco
 */
class LtDropDownMenuDirective {
    constructor(_ssDropDownDirective, _elementRef, _renderer) {
        this._ssDropDownDirective = _ssDropDownDirective;
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this._CONTENT_ELEMENT_CLASS = 'lt-drop-down-menu';
    }
    ngOnInit() {
        this._initialize();
    }
    _initialize() {
        this._contentElement = this._elementRef.nativeElement;
        this._renderer.addClass(this._contentElement, this._CONTENT_ELEMENT_CLASS);
        this._ssDropDownDirective.dropDownMenuElement = this._elementRef;
    }
}
LtDropDownMenuDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ltDropDownMenu]'
            },] }
];
LtDropDownMenuDirective.ctorParameters = () => [
    { type: LtDropDownDirective, decorators: [{ type: Host }] },
    { type: ElementRef },
    { type: Renderer2 }
];

/**
 * @author Oswaldo Pacheco
 */
class LtDropDownToggleDirective {
    constructor(_ssDropDownDirective, _elementRef, _renderer) {
        this._ssDropDownDirective = _ssDropDownDirective;
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this.ssDisabled = false;
        this._DISABLED_CLASS = 'lt-drop-down-toggle-disabled';
        this._CONTENT_ELEMENT_CLASS = 'lt-drop-down-toggle';
        this._CLICK = 'click';
        this._clickEventSubscription = new Subscription();
    }
    ngOnInit() {
        this._initialize();
    }
    ngOnDestroy() {
        this._finalize();
    }
    _initialize() {
        this._build();
        this._listenDropDown();
        this._ssDropDownDirective.dropDownToggleElement = this._elementRef;
    }
    _finalize() {
        this._clickEventSubscription.unsubscribe();
    }
    _build() {
        this._contentElement = this._elementRef.nativeElement;
        this._renderer.addClass(this._contentElement, this._CONTENT_ELEMENT_CLASS);
        if (this.ssDisabled) {
            this._renderer.addClass(this._contentElement, this._DISABLED_CLASS);
        }
        else {
            this._renderer.removeClass(this._contentElement, this._DISABLED_CLASS);
        }
    }
    _listenDropDown() {
        const contentElement = this._getClickElement();
        this._clickEventSubscription = fromEvent(contentElement, this._CLICK)
            .subscribe((event) => {
            event.stopPropagation();
            this._toggle();
        });
    }
    _getClickElement() {
        return this._contentElement ? this._contentElement : this._elementRef.nativeElement;
    }
    _toggle() {
        if (!this.ssDisabled) {
            this._ssDropDownDirective.toggle();
        }
    }
}
LtDropDownToggleDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ltDropDownToggle]'
            },] }
];
LtDropDownToggleDirective.ctorParameters = () => [
    { type: LtDropDownDirective, decorators: [{ type: Host }] },
    { type: ElementRef },
    { type: Renderer2 }
];
LtDropDownToggleDirective.propDecorators = {
    ssDisabled: [{ type: Input }]
};

/**
 * @author Oswaldo Pacheco
 */
class LtDropDownModule {
}
LtDropDownModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    LtDropDownDirective,
                    LtDropDownMenuDirective,
                    LtDropDownToggleDirective
                ],
                declarations: [
                    LtDropDownDirective,
                    LtDropDownMenuDirective,
                    LtDropDownToggleDirective
                ]
            },] }
];

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinkViewComponent {
    constructor() {
        this.LINK_LABEL = 'Link';
        this.PLATFORM_LABEL = 'Platform';
        this.REMOVE_LABEL = 'Remove';
    }
}
LinkThreeLinkViewComponent.decorators = [
    { type: Component, args: [{
                selector: 'link-three-link-view',
                template: "<article class=\"link-three-link-view link-three-link-view-preset-preset-98\">\r\n  <section class=\"link-three-link-view-options\">\r\n    <span class=\"lt-font lt-icon-equal\"></span>\r\n\r\n    <label class=\"lt-txt-m link-three-link-view-number\"></label>\r\n\r\n    <button class=\"link-three-link-view-remove-button\">{{REMOVE_LABEL}}</button>\r\n  </section>\r\n\r\n  <section class=\"link-three-link-view-platform-content\">\r\n    <label class=\"link-three-link-view-platform-label\">{{PLATFORM_LABEL}}</label>\r\n\r\n    <section ssDropDown\r\n             class=\"link-three-link-view-platform-menu-content\">\r\n      <button ssDropDownToggle\r\n              class=\"link-three-link-view-platform-button\">\r\n        <span class=\"lt-font lt-icon-{{link.linkType}}\"></span>\r\n\r\n        <label>{{link.linkType}}</label>\r\n\r\n        <span class=\"lt-font lt-icon-dropdown-up\"></span>\r\n\r\n        <span class=\"lt-font lt-icon-dropdown-down\"></span>\r\n      </button>\r\n\r\n      <section class=\"link-three-link-view-platform-items\"\r\n               ssDropDownMenu>\r\n        <button class=\"link-three-link-view-platform-item\"\r\n                type=\"button\"\r\n                *ngFor=\"let item of []\">\r\n          <span class=\"lt-font lt-icon-{{link.linkType}}\"></span>\r\n\r\n          <label class=\"lt-txt-m\">{{item}}</label>\r\n        </button>\r\n      </section>\r\n    </section>\r\n  </section>\r\n\r\n  <section class=\"link-three-link-view-link-content\">\r\n    <label class=\"lt-txt-s\">{{LINK_LABEL}}</label>\r\n\r\n    <span class=\"lt-font lt-icon-link\"></span>\r\n\r\n    <input class=\"lt-txt-m\"\r\n           type=\"text\"\r\n           value=\"item\">\r\n  </section>\r\n</article>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            },] }
];
LinkThreeLinkViewComponent.ctorParameters = () => [];
LinkThreeLinkViewComponent.propDecorators = {
    link: [{ type: Input }]
};

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelViewComponent {
    constructor() {
        this.ADD_LABEL = '+ Add new link';
        this.DESCRIPTION_EDITOR_LABEL = 'Add/edit/remove links below and then share all your profiles with the world!';
        this.DESCRIPTION_GUIDE_LABEL = `Use the “Add new link” button to get started. Once you have more than one link, you can reorder and edit them. We’re here to help you share your profiles with everyone!`;
        this.SAVE_LABEL = 'Save';
        this.TITLE_EDITOR_LABEL = 'Customize your links';
        this.TITLE_GUIDE_LABEL = `Let's get you started`;
    }
    ngAfterViewInit() {
    }
}
LinkThreeLinksPanelViewComponent.decorators = [
    { type: Component, args: [{
                selector: 'link-three-links-panel-view',
                template: "<article class=\"link-three-links-panel-view link-three-links-panel-preset\">\r\n  <section class=\"link-three-links-panel-view-container-links\">\r\n    <section class=\"link-three-links-panel-view-editor\">\r\n      <label class=\"lt-txt-m-bold link-three-links-panel-view-editor-title\">{{TITLE_EDITOR_LABEL}}</label>\r\n\r\n      <label class=\"lt-txt-m link-three-links-panel-view-editor-description\">{{DESCRIPTION_EDITOR_LABEL}}</label>\r\n    </section>\r\n\r\n    <button class=\"link-three-links-panel-view-button-add\">\r\n      <label class=\"lt-txt-s-bold link-three-links-panel-view-add\">{{ADD_LABEL}}</label>\r\n    </button>\r\n\r\n    <ng-container *ngIf=\"false; else guide\">\r\n      <link-three-link-view></link-three-link-view>\r\n    </ng-container>\r\n\r\n    <ng-template #guide>\r\n      <section class=\"link-three-links-panel-view-guide-content link-three-links-panel-view-guide-content-preset-98\">\r\n        <span class=\"lt-font lt-icon-image\"></span>\r\n\r\n        <section class=\"link-three-links-panel-view-guide\">\r\n          <label class=\"lt-txt-m-bold link-three-links-panel-view-guide-title\">{{TITLE_GUIDE_LABEL}}</label>\r\n\r\n          <label class=\"lt-txt-m link-three-links-panel-view-guide-description\">{{DESCRIPTION_GUIDE_LABEL}}</label>\r\n        </section>\r\n      </section>\r\n    </ng-template>\r\n  </section>\r\n\r\n  <section class=\"link-three-links-panel-view-container-button\">\r\n    <button class=\"link-three-links-panel-view-button-save link-three-links-panel-view-button-save-major-62\">\r\n      <label class=\"lt-txt-s-bold link-three-links-panel-view-save\">{{SAVE_LABEL}}</label>\r\n    </button>\r\n  </section>\r\n</article>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            },] }
];
LinkThreeLinksPanelViewComponent.ctorParameters = () => [];
LinkThreeLinksPanelViewComponent.propDecorators = {
    links: [{ type: Input }]
};

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelViewModule {
}
LinkThreeLinksPanelViewModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    LtDropDownModule,
                ],
                declarations: [
                    LinkThreeLinkViewComponent,
                    LinkThreeLinksPanelViewComponent,
                ],
                exports: [
                    LinkThreeLinkViewComponent,
                    LinkThreeLinksPanelViewComponent,
                ],
                providers: []
            },] }
];

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeMobilePanelViewComponent {
    constructor() {
    }
}
LinkThreeMobilePanelViewComponent.decorators = [
    { type: Component, args: [{
                selector: 'link-three-mobile-panel-view',
                template: "<article class=\"link-three-mobile-panel-view link-three-mobile-panel-view-preset\">\r\n  <section class=\"link-three-mobile-panel-view-border-outside\">\r\n    <section class=\"link-three-mobile-panel-view-border-inside\">\r\n      <section class=\"link-three-mobile-panel-view-border-medium\"></section>\r\n    </section>\r\n  </section>\r\n</article>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            },] }
];
LinkThreeMobilePanelViewComponent.ctorParameters = () => [];

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeMobilePanelViewModule {
}
LinkThreeMobilePanelViewModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                declarations: [
                    LinkThreeMobilePanelViewComponent
                ],
                exports: [
                    LinkThreeMobilePanelViewComponent
                ],
                providers: []
            },] }
];

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkThreeLinkViewComponent, LinkThreeLinksPanelViewComponent, LinkThreeLinksPanelViewModule, LinkThreeMobilePanelViewComponent, LinkThreeMobilePanelViewModule, LinkThreeViewModule, LtDropDownCloseEnum, LtDropDownDirective, LtDropDownMenuDirective, LtDropDownModule, LtDropDownToggleDirective };
//# sourceMappingURL=link-three-view.js.map
