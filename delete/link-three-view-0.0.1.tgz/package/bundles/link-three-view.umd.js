(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/common'), require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('link-three-view', ['exports', '@angular/common', '@angular/core'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["link-three-view"] = {}, global.ng.common, global.ng.core));
})(this, (function (exports, common, core) { 'use strict';

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeViewModule = /** @class */ (function () {
        function LinkThreeViewModule() {
        }
        return LinkThreeViewModule;
    }());
    LinkThreeViewModule.decorators = [
        { type: core.NgModule, args: [{
                    declarations: [],
                    imports: [
                        common.CommonModule
                    ],
                    exports: []
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinkViewComponent = /** @class */ (function () {
        function LinkThreeLinkViewComponent() {
        }
        return LinkThreeLinkViewComponent;
    }());
    LinkThreeLinkViewComponent.decorators = [
        { type: core.Component, args: [{
                    selector: 'link-three-link-view.component',
                    template: "",
                    encapsulation: core.ViewEncapsulation.None,
                    changeDetection: core.ChangeDetectionStrategy.OnPush
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinksPanelViewComponent = /** @class */ (function () {
        function LinkThreeLinksPanelViewComponent() {
        }
        return LinkThreeLinksPanelViewComponent;
    }());
    LinkThreeLinksPanelViewComponent.decorators = [
        { type: core.Component, args: [{
                    selector: 'link-three-links-panel-view',
                    template: "<div>HOLAAAAAAAAAAAA</div>\r\n",
                    encapsulation: core.ViewEncapsulation.None,
                    changeDetection: core.ChangeDetectionStrategy.OnPush
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinksPanelViewModule = /** @class */ (function () {
        function LinkThreeLinksPanelViewModule() {
        }
        return LinkThreeLinksPanelViewModule;
    }());
    LinkThreeLinksPanelViewModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule
                    ],
                    declarations: [
                        LinkThreeLinkViewComponent,
                        LinkThreeLinksPanelViewComponent
                    ],
                    exports: [
                        LinkThreeLinkViewComponent,
                        LinkThreeLinksPanelViewComponent
                    ],
                    providers: []
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.LinkThreeLinkViewComponent = LinkThreeLinkViewComponent;
    exports.LinkThreeLinksPanelViewComponent = LinkThreeLinksPanelViewComponent;
    exports.LinkThreeLinksPanelViewModule = LinkThreeLinksPanelViewModule;
    exports.LinkThreeViewModule = LinkThreeViewModule;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=link-three-view.umd.js.map
