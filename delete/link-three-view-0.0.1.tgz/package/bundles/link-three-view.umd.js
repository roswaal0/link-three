(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/common'), require('@angular/core'), require('rxjs')) :
    typeof define === 'function' && define.amd ? define('link-three-view', ['exports', '@angular/common', '@angular/core', 'rxjs'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["link-three-view"] = {}, global.ng.common, global.ng.core, global.rxjs));
})(this, (function (exports, common, core, rxjs) { 'use strict';

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeViewModule = /** @class */ (function () {
        function LinkThreeViewModule() {
        }
        return LinkThreeViewModule;
    }());
    LinkThreeViewModule.decorators = [
        { type: core.NgModule, args: [{
                    declarations: [],
                    imports: [
                        common.CommonModule
                    ],
                    exports: []
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */
    exports.LtDropDownCloseEnum = void 0;
    (function (LtDropDownCloseEnum) {
        LtDropDownCloseEnum["ALWAYS"] = "always";
        LtDropDownCloseEnum["DISABLED"] = "disabled";
        LtDropDownCloseEnum["OUTSIDE"] = "outside";
    })(exports.LtDropDownCloseEnum || (exports.LtDropDownCloseEnum = {}));

    /**
     * @author Oswaldo Pacheco
     */
    var LtDropDownDirective = /** @class */ (function () {
        function LtDropDownDirective(_elementRef, _renderer) {
            this._elementRef = _elementRef;
            this._renderer = _renderer;
            this._CONTENT_ELEMENT_CLASS = 'lt-drop-down';
            this._OPEN_CLASS = 'lt-drop-down-open';
            this._CLICK = 'click';
            this.dropDownOpenChange = new core.EventEmitter();
            this._clickEventSubscription = new rxjs.Subscription();
            this.autoClose = exports.LtDropDownCloseEnum.ALWAYS;
            this._isOpen = false;
        }
        LtDropDownDirective.prototype.ngOnInit = function () {
            this._initialize();
        };
        LtDropDownDirective.prototype.ngOnDestroy = function () {
            this._finalize();
        };
        LtDropDownDirective.prototype.open = function () {
            if (!this._isOpen) {
                this._isOpen = true;
                if (this.autoClose !== exports.LtDropDownCloseEnum.DISABLED) {
                    this._listenAutoClose();
                }
                this._renderer.addClass(this._contentElement, this._OPEN_CLASS);
                this.dropDownOpenChange.emit(true);
            }
        };
        LtDropDownDirective.prototype.close = function () {
            if (this._isOpen) {
                this._isOpen = false;
                this._renderer.removeClass(this._contentElement, this._OPEN_CLASS);
                this._clickEventSubscription.unsubscribe();
                this.dropDownOpenChange.emit(false);
            }
        };
        LtDropDownDirective.prototype.toggle = function () {
            if (this._isOpen) {
                this.close();
            }
            else {
                this.open();
            }
        };
        Object.defineProperty(LtDropDownDirective.prototype, "dropDownToggleElement", {
            set: function (dropDownToggleElement) {
                this._dropDownToggleElement = dropDownToggleElement;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(LtDropDownDirective.prototype, "dropDownMenuElement", {
            set: function (dropDownMenuElement) {
                this._dropDownMenuElement = dropDownMenuElement;
            },
            enumerable: false,
            configurable: true
        });
        LtDropDownDirective.prototype._initialize = function () {
            this._build();
        };
        LtDropDownDirective.prototype._finalize = function () {
            this._clickEventSubscription.unsubscribe();
            if (this._dropDownMenuElement) {
                this._dropDownMenuElement.nativeElement.remove();
            }
        };
        LtDropDownDirective.prototype._build = function () {
            this._contentElement = this._elementRef.nativeElement;
            this._renderer.addClass(this._contentElement, this._CONTENT_ELEMENT_CLASS);
        };
        LtDropDownDirective.prototype._listenAutoClose = function () {
            var _this = this;
            this._clickEventSubscription = rxjs.fromEvent(document, this._CLICK)
                .subscribe(function (event) {
                _this._autoCloseEvent(event);
            });
        };
        LtDropDownDirective.prototype._autoCloseEvent = function (event) {
            if (event) {
                var targetElement = event.target;
                if (this._dropDownToggleElement &&
                    this._dropDownToggleElement.nativeElement.contains(targetElement)) {
                    return;
                }
                if (this.autoClose === exports.LtDropDownCloseEnum.OUTSIDE &&
                    this._dropDownMenuElement &&
                    this._dropDownMenuElement.nativeElement.contains(targetElement)) {
                    return;
                }
            }
            this.close();
        };
        return LtDropDownDirective;
    }());
    LtDropDownDirective.decorators = [
        { type: core.Directive, args: [{
                    selector: '[ltDropDown]'
                },] }
    ];
    LtDropDownDirective.ctorParameters = function () { return [
        { type: core.ElementRef },
        { type: core.Renderer2 }
    ]; };
    LtDropDownDirective.propDecorators = {
        dropDownOpenChange: [{ type: core.Output }],
        autoClose: [{ type: core.Input }]
    };

    /**
     * @author Oswaldo Pacheco
     */
    var LtDropDownMenuDirective = /** @class */ (function () {
        function LtDropDownMenuDirective(_ssDropDownDirective, _elementRef, _renderer) {
            this._ssDropDownDirective = _ssDropDownDirective;
            this._elementRef = _elementRef;
            this._renderer = _renderer;
            this._CONTENT_ELEMENT_CLASS = 'lt-drop-down-menu';
        }
        LtDropDownMenuDirective.prototype.ngOnInit = function () {
            this._initialize();
        };
        LtDropDownMenuDirective.prototype._initialize = function () {
            this._contentElement = this._elementRef.nativeElement;
            this._renderer.addClass(this._contentElement, this._CONTENT_ELEMENT_CLASS);
            this._ssDropDownDirective.dropDownMenuElement = this._elementRef;
        };
        return LtDropDownMenuDirective;
    }());
    LtDropDownMenuDirective.decorators = [
        { type: core.Directive, args: [{
                    selector: '[ltDropDownMenu]'
                },] }
    ];
    LtDropDownMenuDirective.ctorParameters = function () { return [
        { type: LtDropDownDirective, decorators: [{ type: core.Host }] },
        { type: core.ElementRef },
        { type: core.Renderer2 }
    ]; };

    /**
     * @author Oswaldo Pacheco
     */
    var LtDropDownToggleDirective = /** @class */ (function () {
        function LtDropDownToggleDirective(_ssDropDownDirective, _elementRef, _renderer) {
            this._ssDropDownDirective = _ssDropDownDirective;
            this._elementRef = _elementRef;
            this._renderer = _renderer;
            this.ssDisabled = false;
            this._DISABLED_CLASS = 'lt-drop-down-toggle-disabled';
            this._CONTENT_ELEMENT_CLASS = 'lt-drop-down-toggle';
            this._CLICK = 'click';
            this._clickEventSubscription = new rxjs.Subscription();
        }
        LtDropDownToggleDirective.prototype.ngOnInit = function () {
            this._initialize();
        };
        LtDropDownToggleDirective.prototype.ngOnDestroy = function () {
            this._finalize();
        };
        LtDropDownToggleDirective.prototype._initialize = function () {
            this._build();
            this._listenDropDown();
            this._ssDropDownDirective.dropDownToggleElement = this._elementRef;
        };
        LtDropDownToggleDirective.prototype._finalize = function () {
            this._clickEventSubscription.unsubscribe();
        };
        LtDropDownToggleDirective.prototype._build = function () {
            this._contentElement = this._elementRef.nativeElement;
            this._renderer.addClass(this._contentElement, this._CONTENT_ELEMENT_CLASS);
            if (this.ssDisabled) {
                this._renderer.addClass(this._contentElement, this._DISABLED_CLASS);
            }
            else {
                this._renderer.removeClass(this._contentElement, this._DISABLED_CLASS);
            }
        };
        LtDropDownToggleDirective.prototype._listenDropDown = function () {
            var _this = this;
            var contentElement = this._getClickElement();
            this._clickEventSubscription = rxjs.fromEvent(contentElement, this._CLICK)
                .subscribe(function (event) {
                event.stopPropagation();
                _this._toggle();
            });
        };
        LtDropDownToggleDirective.prototype._getClickElement = function () {
            return this._contentElement ? this._contentElement : this._elementRef.nativeElement;
        };
        LtDropDownToggleDirective.prototype._toggle = function () {
            if (!this.ssDisabled) {
                this._ssDropDownDirective.toggle();
            }
        };
        return LtDropDownToggleDirective;
    }());
    LtDropDownToggleDirective.decorators = [
        { type: core.Directive, args: [{
                    selector: '[ltDropDownToggle]'
                },] }
    ];
    LtDropDownToggleDirective.ctorParameters = function () { return [
        { type: LtDropDownDirective, decorators: [{ type: core.Host }] },
        { type: core.ElementRef },
        { type: core.Renderer2 }
    ]; };
    LtDropDownToggleDirective.propDecorators = {
        ssDisabled: [{ type: core.Input }]
    };

    /**
     * @author Oswaldo Pacheco
     */
    var LtDropDownModule = /** @class */ (function () {
        function LtDropDownModule() {
        }
        return LtDropDownModule;
    }());
    LtDropDownModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule
                    ],
                    exports: [
                        LtDropDownDirective,
                        LtDropDownMenuDirective,
                        LtDropDownToggleDirective
                    ],
                    declarations: [
                        LtDropDownDirective,
                        LtDropDownMenuDirective,
                        LtDropDownToggleDirective
                    ]
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinkViewComponent = /** @class */ (function () {
        function LinkThreeLinkViewComponent() {
            this.LINK_LABEL = 'Link';
            this.PLATFORM_LABEL = 'Platform';
            this.REMOVE_LABEL = 'Remove';
        }
        return LinkThreeLinkViewComponent;
    }());
    LinkThreeLinkViewComponent.decorators = [
        { type: core.Component, args: [{
                    selector: 'link-three-link-view',
                    template: "<article class=\"link-three-link-view link-three-link-view-preset-preset-98\">\r\n  <section class=\"link-three-link-view-options\">\r\n    <span class=\"lt-font lt-icon-equal\"></span>\r\n\r\n    <label class=\"lt-txt-m link-three-link-view-number\"></label>\r\n\r\n    <button class=\"link-three-link-view-remove-button\">{{REMOVE_LABEL}}</button>\r\n  </section>\r\n\r\n  <section class=\"link-three-link-view-platform-content\">\r\n    <label class=\"link-three-link-view-platform-label\">{{PLATFORM_LABEL}}</label>\r\n\r\n    <section ssDropDown\r\n             class=\"link-three-link-view-platform-menu-content\">\r\n      <button ssDropDownToggle\r\n              class=\"link-three-link-view-platform-button\">\r\n        <span class=\"lt-font lt-icon-{{link.linkType}}\"></span>\r\n\r\n        <label>{{link.linkType}}</label>\r\n\r\n        <span class=\"lt-font lt-icon-dropdown-up\"></span>\r\n\r\n        <span class=\"lt-font lt-icon-dropdown-down\"></span>\r\n      </button>\r\n\r\n      <section class=\"link-three-link-view-platform-items\"\r\n               ssDropDownMenu>\r\n        <button class=\"link-three-link-view-platform-item\"\r\n                type=\"button\"\r\n                *ngFor=\"let item of []\">\r\n          <span class=\"lt-font lt-icon-{{link.linkType}}\"></span>\r\n\r\n          <label class=\"lt-txt-m\">{{item}}</label>\r\n        </button>\r\n      </section>\r\n    </section>\r\n  </section>\r\n\r\n  <section class=\"link-three-link-view-link-content\">\r\n    <label class=\"lt-txt-s\">{{LINK_LABEL}}</label>\r\n\r\n    <span class=\"lt-font lt-icon-link\"></span>\r\n\r\n    <input class=\"lt-txt-m\"\r\n           type=\"text\"\r\n           value=\"item\">\r\n  </section>\r\n</article>\r\n",
                    encapsulation: core.ViewEncapsulation.None,
                    changeDetection: core.ChangeDetectionStrategy.OnPush
                },] }
    ];
    LinkThreeLinkViewComponent.ctorParameters = function () { return []; };
    LinkThreeLinkViewComponent.propDecorators = {
        link: [{ type: core.Input }]
    };

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinksPanelViewComponent = /** @class */ (function () {
        function LinkThreeLinksPanelViewComponent() {
            this.ADD_LABEL = '+ Add new link';
            this.DESCRIPTION_EDITOR_LABEL = 'Add/edit/remove links below and then share all your profiles with the world!';
            this.DESCRIPTION_GUIDE_LABEL = "Use the \u201CAdd new link\u201D button to get started. Once you have more than one link, you can reorder and edit them. We\u2019re here to help you share your profiles with everyone!";
            this.SAVE_LABEL = 'Save';
            this.TITLE_EDITOR_LABEL = 'Customize your links';
            this.TITLE_GUIDE_LABEL = "Let's get you started";
        }
        LinkThreeLinksPanelViewComponent.prototype.ngAfterViewInit = function () {
        };
        return LinkThreeLinksPanelViewComponent;
    }());
    LinkThreeLinksPanelViewComponent.decorators = [
        { type: core.Component, args: [{
                    selector: 'link-three-links-panel-view',
                    template: "<article class=\"link-three-links-panel-view link-three-links-panel-preset\">\r\n  <section class=\"link-three-links-panel-view-container-links\">\r\n    <section class=\"link-three-links-panel-view-editor\">\r\n      <label class=\"lt-txt-m-bold link-three-links-panel-view-editor-title\">{{TITLE_EDITOR_LABEL}}</label>\r\n\r\n      <label class=\"lt-txt-m link-three-links-panel-view-editor-description\">{{DESCRIPTION_EDITOR_LABEL}}</label>\r\n    </section>\r\n\r\n    <button class=\"link-three-links-panel-view-button-add\">\r\n      <label class=\"lt-txt-s-bold link-three-links-panel-view-add\">{{ADD_LABEL}}</label>\r\n    </button>\r\n\r\n    <ng-container *ngIf=\"false; else guide\">\r\n      <link-three-link-view></link-three-link-view>\r\n    </ng-container>\r\n\r\n    <ng-template #guide>\r\n      <section class=\"link-three-links-panel-view-guide-content link-three-links-panel-view-guide-content-preset-98\">\r\n        <span class=\"lt-font lt-icon-image\"></span>\r\n\r\n        <section class=\"link-three-links-panel-view-guide\">\r\n          <label class=\"lt-txt-m-bold link-three-links-panel-view-guide-title\">{{TITLE_GUIDE_LABEL}}</label>\r\n\r\n          <label class=\"lt-txt-m link-three-links-panel-view-guide-description\">{{DESCRIPTION_GUIDE_LABEL}}</label>\r\n        </section>\r\n      </section>\r\n    </ng-template>\r\n  </section>\r\n\r\n  <section class=\"link-three-links-panel-view-container-button\">\r\n    <button class=\"link-three-links-panel-view-button-save link-three-links-panel-view-button-save-major-62\">\r\n      <label class=\"lt-txt-s-bold link-three-links-panel-view-save\">{{SAVE_LABEL}}</label>\r\n    </button>\r\n  </section>\r\n</article>\r\n",
                    encapsulation: core.ViewEncapsulation.None,
                    changeDetection: core.ChangeDetectionStrategy.OnPush
                },] }
    ];
    LinkThreeLinksPanelViewComponent.ctorParameters = function () { return []; };
    LinkThreeLinksPanelViewComponent.propDecorators = {
        links: [{ type: core.Input }]
    };

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinksPanelViewModule = /** @class */ (function () {
        function LinkThreeLinksPanelViewModule() {
        }
        return LinkThreeLinksPanelViewModule;
    }());
    LinkThreeLinksPanelViewModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule,
                        LtDropDownModule,
                    ],
                    declarations: [
                        LinkThreeLinkViewComponent,
                        LinkThreeLinksPanelViewComponent,
                    ],
                    exports: [
                        LinkThreeLinkViewComponent,
                        LinkThreeLinksPanelViewComponent,
                    ],
                    providers: []
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeMobilePanelViewComponent = /** @class */ (function () {
        function LinkThreeMobilePanelViewComponent() {
        }
        return LinkThreeMobilePanelViewComponent;
    }());
    LinkThreeMobilePanelViewComponent.decorators = [
        { type: core.Component, args: [{
                    selector: 'link-three-mobile-panel-view',
                    template: "<article class=\"link-three-mobile-panel-view link-three-mobile-panel-view-preset\">\r\n  <section class=\"link-three-mobile-panel-view-border-outside\">\r\n    <section class=\"link-three-mobile-panel-view-border-inside\">\r\n      <section class=\"link-three-mobile-panel-view-border-medium\"></section>\r\n    </section>\r\n  </section>\r\n</article>\r\n",
                    encapsulation: core.ViewEncapsulation.None,
                    changeDetection: core.ChangeDetectionStrategy.OnPush
                },] }
    ];
    LinkThreeMobilePanelViewComponent.ctorParameters = function () { return []; };

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeMobilePanelViewModule = /** @class */ (function () {
        function LinkThreeMobilePanelViewModule() {
        }
        return LinkThreeMobilePanelViewModule;
    }());
    LinkThreeMobilePanelViewModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule
                    ],
                    declarations: [
                        LinkThreeMobilePanelViewComponent
                    ],
                    exports: [
                        LinkThreeMobilePanelViewComponent
                    ],
                    providers: []
                },] }
    ];

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.LinkThreeLinkViewComponent = LinkThreeLinkViewComponent;
    exports.LinkThreeLinksPanelViewComponent = LinkThreeLinksPanelViewComponent;
    exports.LinkThreeLinksPanelViewModule = LinkThreeLinksPanelViewModule;
    exports.LinkThreeMobilePanelViewComponent = LinkThreeMobilePanelViewComponent;
    exports.LinkThreeMobilePanelViewModule = LinkThreeMobilePanelViewModule;
    exports.LinkThreeViewModule = LinkThreeViewModule;
    exports.LtDropDownDirective = LtDropDownDirective;
    exports.LtDropDownMenuDirective = LtDropDownMenuDirective;
    exports.LtDropDownModule = LtDropDownModule;
    exports.LtDropDownToggleDirective = LtDropDownToggleDirective;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=link-three-view.umd.js.map
