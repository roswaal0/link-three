import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';

class LinkThreeApiModule {
}
LinkThreeApiModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
LinkThreeApiModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule });
LinkThreeApiModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule, imports: [[]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [],
                    exports: []
                }]
        }] });

class LinkResponse {
}

/**
 * @author Oswaldo Pacheco
 */
class UserResponse {
}

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */
var LinkTypeEnum;
(function (LinkTypeEnum) {
    LinkTypeEnum["CODEPEN"] = "Codepen";
    LinkTypeEnum["CODEWARS"] = "Codewars";
    LinkTypeEnum["DEV_TO"] = "Dev.to";
    LinkTypeEnum["FACEBOOK"] = "Facebook";
    LinkTypeEnum["FREE_CODE_CAMP"] = "freeCodeCamp";
    LinkTypeEnum["FRONTEND_MENTOR"] = "Frontend Mentor";
    LinkTypeEnum["GITHUB"] = "GitHub";
    LinkTypeEnum["GITLAB"] = "GitLab";
    LinkTypeEnum["HASHNODE"] = "Hashnode";
    LinkTypeEnum["LINKED_IN"] = "LinkedIn";
    LinkTypeEnum["STACK_OVERFLOW"] = "Stack Overflow";
    LinkTypeEnum["TWITCH"] = "Twitch";
    LinkTypeEnum["TWITTER"] = "Twitter";
    LinkTypeEnum["YOUTUBE"] = "YouTube";
})(LinkTypeEnum || (LinkTypeEnum = {}));

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkResponse, LinkThreeApiModule, LinkTypeEnum, UserResponse };
//# sourceMappingURL=link-three-link-three-api.js.map
