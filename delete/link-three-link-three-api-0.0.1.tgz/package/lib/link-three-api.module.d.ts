import * as i0 from "@angular/core";
export declare class LinkThreeApiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkThreeApiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkThreeApiModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkThreeApiModule>;
}
