/**
 * @author Oswaldo Pacheco
 */
import { LinkTypeEnum } from '../enum/link-type.enum';
export declare class LinkResponse {
    linkId: string;
    linkType: LinkTypeEnum;
    platform: string;
    userId: string;
}
