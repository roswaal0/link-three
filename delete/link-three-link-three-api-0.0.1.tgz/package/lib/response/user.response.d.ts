/**
 * @author Oswaldo Pacheco
 */
export declare class UserResponse {
    avatar: string;
    email: string;
    firstName: string;
    lastName: string;
    userId: string;
}
