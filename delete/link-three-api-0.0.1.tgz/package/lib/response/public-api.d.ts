/**
 * @author Oswaldo Pacheco
 */
export { UserResponse } from './user.response';
