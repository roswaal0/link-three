(function (global, factory) {
        typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core')) :
        typeof define === 'function' && define.amd ? define('link-three-api', ['exports', '@angular/core'], factory) :
        (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["link-three-api"] = {}, global.ng.core));
})(this, (function (exports, i0) { 'use strict';

        function _interopNamespace(e) {
                if (e && e.__esModule) return e;
                var n = Object.create(null);
                if (e) {
                        Object.keys(e).forEach(function (k) {
                                if (k !== 'default') {
                                        var d = Object.getOwnPropertyDescriptor(e, k);
                                        Object.defineProperty(n, k, d.get ? d : {
                                                enumerable: true,
                                                get: function () { return e[k]; }
                                        });
                                }
                        });
                }
                n["default"] = e;
                return Object.freeze(n);
        }

        var i0__namespace = /*#__PURE__*/_interopNamespace(i0);

        var LinkThreeApiModule = /** @class */ (function () {
            function LinkThreeApiModule() {
            }
            return LinkThreeApiModule;
        }());
        LinkThreeApiModule.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeApiModule, deps: [], target: i0__namespace.ɵɵFactoryTarget.NgModule });
        LinkThreeApiModule.ɵmod = i0__namespace.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeApiModule });
        LinkThreeApiModule.ɵinj = i0__namespace.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeApiModule, imports: [[]] });
        i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: LinkThreeApiModule, decorators: [{
                    type: i0.NgModule,
                    args: [{
                            declarations: [],
                            imports: [],
                            exports: []
                        }]
                }] });

        /**
         * @author Oswaldo Pacheco
         */
        var UserResponse = /** @class */ (function () {
            function UserResponse() {
            }
            return UserResponse;
        }());

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * @author Oswaldo Pacheco
         */

        /**
         * Generated bundle index. Do not edit.
         */

        exports.LinkThreeApiModule = LinkThreeApiModule;
        exports.UserResponse = UserResponse;

        Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=link-three-api.umd.js.map
