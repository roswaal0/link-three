import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';

class LinkThreeApiModule {
}
LinkThreeApiModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
LinkThreeApiModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule });
LinkThreeApiModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule, imports: [[]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: LinkThreeApiModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [],
                    exports: []
                }]
        }] });

/**
 * @author Oswaldo Pacheco
 */
class UserResponse {
}

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkThreeApiModule, UserResponse };
//# sourceMappingURL=link-three-api.js.map
