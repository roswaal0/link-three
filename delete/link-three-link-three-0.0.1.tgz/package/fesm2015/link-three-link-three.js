import * as i0 from '@angular/core';
import { NgModule, Component, ViewEncapsulation, ChangeDetectionStrategy } from '@angular/core';
import * as i1 from '@link-three/link-three-core';
import { LinkThreeLinksPanelContainerModule, LinkThreeMobilePanelContainerModule } from '@link-three/link-three-core';
import * as i2 from '@link-three/link-three-view';
import { LinkThreeLinksPanelViewModule, LinkThreeMobilePanelViewModule } from '@link-three/link-three-view';
import * as i3 from '@ngrx/component';
import { ReactiveComponentModule } from '@ngrx/component';
import { CommonModule } from '@angular/common';

class LinkThreeModule {
}
LinkThreeModule.ɵfac = function LinkThreeModule_Factory(t) { return new (t || LinkThreeModule)(); };
LinkThreeModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LinkThreeModule });
LinkThreeModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [[]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [],
                exports: []
            }]
    }], null, null); })();

/**
 * @author Oswaldo Pacheco
 */
const _c0 = function (a0) { return [a0]; };
class LinkThreeLinksPanelComponent {
}
LinkThreeLinksPanelComponent.ɵfac = function LinkThreeLinksPanelComponent_Factory(t) { return new (t || LinkThreeLinksPanelComponent)(); };
LinkThreeLinksPanelComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LinkThreeLinksPanelComponent, selectors: [["link-three-links-panel"]], decls: 4, vars: 5, consts: [["smartComponent", ""], [3, "links"]], template: function LinkThreeLinksPanelComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "link-three-links-panel-container", null, 0);
        i0.ɵɵelement(2, "link-three-links-panel-view", 1);
        i0.ɵɵpipe(3, "ngrxPush");
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        const _r0 = i0.ɵɵreference(1);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("links", i0.ɵɵpureFunction1(3, _c0, i0.ɵɵpipeBind1(3, 1, _r0.links$)));
    } }, directives: [i1.LinkThreeLinksPanelContainerComponent, i2.LinkThreeLinksPanelViewComponent], pipes: [i3.PushPipe], encapsulation: 2, changeDetection: 0 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeLinksPanelComponent, [{
        type: Component,
        args: [{
                selector: 'link-three-links-panel',
                templateUrl: './link-three-links-panel.component.html',
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], null, null); })();

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeLinksPanelModule {
}
LinkThreeLinksPanelModule.ɵfac = function LinkThreeLinksPanelModule_Factory(t) { return new (t || LinkThreeLinksPanelModule)(); };
LinkThreeLinksPanelModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LinkThreeLinksPanelModule });
LinkThreeLinksPanelModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [[
            LinkThreeLinksPanelContainerModule,
            LinkThreeLinksPanelViewModule,
            CommonModule,
            ReactiveComponentModule,
        ]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeLinksPanelModule, [{
        type: NgModule,
        args: [{
                imports: [
                    LinkThreeLinksPanelContainerModule,
                    LinkThreeLinksPanelViewModule,
                    CommonModule,
                    ReactiveComponentModule,
                ],
                declarations: [
                    LinkThreeLinksPanelComponent
                ],
                exports: [
                    LinkThreeLinksPanelComponent
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(LinkThreeLinksPanelModule, { declarations: [LinkThreeLinksPanelComponent], imports: [LinkThreeLinksPanelContainerModule,
        LinkThreeLinksPanelViewModule,
        CommonModule,
        ReactiveComponentModule], exports: [LinkThreeLinksPanelComponent] }); })();

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeMobilePanelComponent {
}
LinkThreeMobilePanelComponent.ɵfac = function LinkThreeMobilePanelComponent_Factory(t) { return new (t || LinkThreeMobilePanelComponent)(); };
LinkThreeMobilePanelComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LinkThreeMobilePanelComponent, selectors: [["link-three-mobile-panel"]], decls: 2, vars: 0, template: function LinkThreeMobilePanelComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "link-three-mobile-panel-container");
        i0.ɵɵelement(1, "link-three-mobile-panel-view");
        i0.ɵɵelementEnd();
    } }, directives: [i1.LinkThreeMobilePanelContainerComponent, i2.LinkThreeMobilePanelViewComponent], encapsulation: 2, changeDetection: 0 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeMobilePanelComponent, [{
        type: Component,
        args: [{
                selector: 'link-three-mobile-panel',
                templateUrl: './link-three-mobile-panel.component.html',
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], null, null); })();

/**
 * @author Oswaldo Pacheco
 */
class LinkThreeMobilePanelModule {
}
LinkThreeMobilePanelModule.ɵfac = function LinkThreeMobilePanelModule_Factory(t) { return new (t || LinkThreeMobilePanelModule)(); };
LinkThreeMobilePanelModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LinkThreeMobilePanelModule });
LinkThreeMobilePanelModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [[
            LinkThreeMobilePanelContainerModule,
            LinkThreeMobilePanelViewModule,
            CommonModule,
            ReactiveComponentModule,
        ]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkThreeMobilePanelModule, [{
        type: NgModule,
        args: [{
                imports: [
                    LinkThreeMobilePanelContainerModule,
                    LinkThreeMobilePanelViewModule,
                    CommonModule,
                    ReactiveComponentModule,
                ],
                declarations: [
                    LinkThreeMobilePanelComponent
                ],
                exports: [
                    LinkThreeMobilePanelComponent
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(LinkThreeMobilePanelModule, { declarations: [LinkThreeMobilePanelComponent], imports: [LinkThreeMobilePanelContainerModule,
        LinkThreeMobilePanelViewModule,
        CommonModule,
        ReactiveComponentModule], exports: [LinkThreeMobilePanelComponent] }); })();

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * @author Oswaldo Pacheco
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LinkThreeLinksPanelComponent, LinkThreeLinksPanelModule, LinkThreeMobilePanelComponent, LinkThreeMobilePanelModule, LinkThreeModule };
//# sourceMappingURL=link-three-link-three.js.map
