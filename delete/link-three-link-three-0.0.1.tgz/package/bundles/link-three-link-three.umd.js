(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@link-three/link-three-core'), require('@link-three/link-three-view'), require('@ngrx/component'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('@link-three/link-three', ['exports', '@angular/core', '@link-three/link-three-core', '@link-three/link-three-view', '@ngrx/component', '@angular/common'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global["link-three"] = global["link-three"] || {}, global["link-three"]["link-three"] = {}), global.ng.core, global.i1, global.i2, global.i3, global.ng.common));
})(this, (function (exports, i0, i1, i2, i3, common) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
    var i1__namespace = /*#__PURE__*/_interopNamespace(i1);
    var i2__namespace = /*#__PURE__*/_interopNamespace(i2);
    var i3__namespace = /*#__PURE__*/_interopNamespace(i3);

    var LinkThreeModule = /** @class */ (function () {
        function LinkThreeModule() {
        }
        return LinkThreeModule;
    }());
    LinkThreeModule.ɵfac = function LinkThreeModule_Factory(t) { return new (t || LinkThreeModule)(); };
    LinkThreeModule.ɵmod = /*@__PURE__*/ i0__namespace.ɵɵdefineNgModule({ type: LinkThreeModule });
    LinkThreeModule.ɵinj = /*@__PURE__*/ i0__namespace.ɵɵdefineInjector({ imports: [[]] });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeModule, [{
                type: i0.NgModule,
                args: [{
                        declarations: [],
                        imports: [],
                        exports: []
                    }]
            }], null, null);
    })();

    /**
     * @author Oswaldo Pacheco
     */
    var _c0 = function (a0) { return [a0]; };
    var LinkThreeLinksPanelComponent = /** @class */ (function () {
        function LinkThreeLinksPanelComponent() {
        }
        return LinkThreeLinksPanelComponent;
    }());
    LinkThreeLinksPanelComponent.ɵfac = function LinkThreeLinksPanelComponent_Factory(t) { return new (t || LinkThreeLinksPanelComponent)(); };
    LinkThreeLinksPanelComponent.ɵcmp = /*@__PURE__*/ i0__namespace.ɵɵdefineComponent({ type: LinkThreeLinksPanelComponent, selectors: [["link-three-links-panel"]], decls: 4, vars: 5, consts: [["smartComponent", ""], [3, "links"]], template: function LinkThreeLinksPanelComponent_Template(rf, ctx) {
            if (rf & 1) {
                i0__namespace.ɵɵelementStart(0, "link-three-links-panel-container", null, 0);
                i0__namespace.ɵɵelement(2, "link-three-links-panel-view", 1);
                i0__namespace.ɵɵpipe(3, "ngrxPush");
                i0__namespace.ɵɵelementEnd();
            }
            if (rf & 2) {
                var _r0 = i0__namespace.ɵɵreference(1);
                i0__namespace.ɵɵadvance(2);
                i0__namespace.ɵɵproperty("links", i0__namespace.ɵɵpureFunction1(3, _c0, i0__namespace.ɵɵpipeBind1(3, 1, _r0.links$)));
            }
        }, directives: [i1__namespace.LinkThreeLinksPanelContainerComponent, i2__namespace.LinkThreeLinksPanelViewComponent], pipes: [i3__namespace.PushPipe], encapsulation: 2, changeDetection: 0 });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeLinksPanelComponent, [{
                type: i0.Component,
                args: [{
                        selector: 'link-three-links-panel',
                        templateUrl: './link-three-links-panel.component.html',
                        encapsulation: i0.ViewEncapsulation.None,
                        changeDetection: i0.ChangeDetectionStrategy.OnPush
                    }]
            }], null, null);
    })();

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeLinksPanelModule = /** @class */ (function () {
        function LinkThreeLinksPanelModule() {
        }
        return LinkThreeLinksPanelModule;
    }());
    LinkThreeLinksPanelModule.ɵfac = function LinkThreeLinksPanelModule_Factory(t) { return new (t || LinkThreeLinksPanelModule)(); };
    LinkThreeLinksPanelModule.ɵmod = /*@__PURE__*/ i0__namespace.ɵɵdefineNgModule({ type: LinkThreeLinksPanelModule });
    LinkThreeLinksPanelModule.ɵinj = /*@__PURE__*/ i0__namespace.ɵɵdefineInjector({ imports: [[
                i1.LinkThreeLinksPanelContainerModule,
                i2.LinkThreeLinksPanelViewModule,
                common.CommonModule,
                i3.ReactiveComponentModule,
            ]] });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeLinksPanelModule, [{
                type: i0.NgModule,
                args: [{
                        imports: [
                            i1.LinkThreeLinksPanelContainerModule,
                            i2.LinkThreeLinksPanelViewModule,
                            common.CommonModule,
                            i3.ReactiveComponentModule,
                        ],
                        declarations: [
                            LinkThreeLinksPanelComponent
                        ],
                        exports: [
                            LinkThreeLinksPanelComponent
                        ]
                    }]
            }], null, null);
    })();
    (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && i0__namespace.ɵɵsetNgModuleScope(LinkThreeLinksPanelModule, { declarations: [LinkThreeLinksPanelComponent], imports: [i1.LinkThreeLinksPanelContainerModule,
                i2.LinkThreeLinksPanelViewModule,
                common.CommonModule,
                i3.ReactiveComponentModule], exports: [LinkThreeLinksPanelComponent] });
    })();

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeMobilePanelComponent = /** @class */ (function () {
        function LinkThreeMobilePanelComponent() {
        }
        return LinkThreeMobilePanelComponent;
    }());
    LinkThreeMobilePanelComponent.ɵfac = function LinkThreeMobilePanelComponent_Factory(t) { return new (t || LinkThreeMobilePanelComponent)(); };
    LinkThreeMobilePanelComponent.ɵcmp = /*@__PURE__*/ i0__namespace.ɵɵdefineComponent({ type: LinkThreeMobilePanelComponent, selectors: [["link-three-mobile-panel"]], decls: 2, vars: 0, template: function LinkThreeMobilePanelComponent_Template(rf, ctx) {
            if (rf & 1) {
                i0__namespace.ɵɵelementStart(0, "link-three-mobile-panel-container");
                i0__namespace.ɵɵelement(1, "link-three-mobile-panel-view");
                i0__namespace.ɵɵelementEnd();
            }
        }, directives: [i1__namespace.LinkThreeMobilePanelContainerComponent, i2__namespace.LinkThreeMobilePanelViewComponent], encapsulation: 2, changeDetection: 0 });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeMobilePanelComponent, [{
                type: i0.Component,
                args: [{
                        selector: 'link-three-mobile-panel',
                        templateUrl: './link-three-mobile-panel.component.html',
                        encapsulation: i0.ViewEncapsulation.None,
                        changeDetection: i0.ChangeDetectionStrategy.OnPush
                    }]
            }], null, null);
    })();

    /**
     * @author Oswaldo Pacheco
     */
    var LinkThreeMobilePanelModule = /** @class */ (function () {
        function LinkThreeMobilePanelModule() {
        }
        return LinkThreeMobilePanelModule;
    }());
    LinkThreeMobilePanelModule.ɵfac = function LinkThreeMobilePanelModule_Factory(t) { return new (t || LinkThreeMobilePanelModule)(); };
    LinkThreeMobilePanelModule.ɵmod = /*@__PURE__*/ i0__namespace.ɵɵdefineNgModule({ type: LinkThreeMobilePanelModule });
    LinkThreeMobilePanelModule.ɵinj = /*@__PURE__*/ i0__namespace.ɵɵdefineInjector({ imports: [[
                i1.LinkThreeMobilePanelContainerModule,
                i2.LinkThreeMobilePanelViewModule,
                common.CommonModule,
                i3.ReactiveComponentModule,
            ]] });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0__namespace.ɵsetClassMetadata(LinkThreeMobilePanelModule, [{
                type: i0.NgModule,
                args: [{
                        imports: [
                            i1.LinkThreeMobilePanelContainerModule,
                            i2.LinkThreeMobilePanelViewModule,
                            common.CommonModule,
                            i3.ReactiveComponentModule,
                        ],
                        declarations: [
                            LinkThreeMobilePanelComponent
                        ],
                        exports: [
                            LinkThreeMobilePanelComponent
                        ]
                    }]
            }], null, null);
    })();
    (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && i0__namespace.ɵɵsetNgModuleScope(LinkThreeMobilePanelModule, { declarations: [LinkThreeMobilePanelComponent], imports: [i1.LinkThreeMobilePanelContainerModule,
                i2.LinkThreeMobilePanelViewModule,
                common.CommonModule,
                i3.ReactiveComponentModule], exports: [LinkThreeMobilePanelComponent] });
    })();

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * @author Oswaldo Pacheco
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.LinkThreeLinksPanelComponent = LinkThreeLinksPanelComponent;
    exports.LinkThreeLinksPanelModule = LinkThreeLinksPanelModule;
    exports.LinkThreeMobilePanelComponent = LinkThreeMobilePanelComponent;
    exports.LinkThreeMobilePanelModule = LinkThreeMobilePanelModule;
    exports.LinkThreeModule = LinkThreeModule;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=link-three-link-three.umd.js.map
